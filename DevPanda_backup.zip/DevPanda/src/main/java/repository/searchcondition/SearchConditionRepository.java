package repository.searchcondition;

public interface SearchConditionRepository {

}
