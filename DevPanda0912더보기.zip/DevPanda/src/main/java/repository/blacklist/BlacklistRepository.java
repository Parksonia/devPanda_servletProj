package repository.blacklist;

public interface BlacklistRepository {

}
