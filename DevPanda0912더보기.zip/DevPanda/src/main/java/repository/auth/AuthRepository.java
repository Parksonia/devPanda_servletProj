package repository.auth;

public interface AuthRepository {

}
