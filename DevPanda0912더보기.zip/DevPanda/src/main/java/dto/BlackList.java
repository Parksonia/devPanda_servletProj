package dto;

public class BlackList {

}
