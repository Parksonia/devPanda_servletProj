package dto;

public class SearchCondition {

}
