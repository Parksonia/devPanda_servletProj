package repository.notice;

public interface NoticeRepository {

}
