package service;

import dto.Auction;

public interface AuctionInsertService {
	void insertAuction(Auction auction);
}
