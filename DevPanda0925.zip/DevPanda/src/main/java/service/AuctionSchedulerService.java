package service;

public interface AuctionSchedulerService {
    void startScheduler();
}
