package repository.auction;

import dto.Auction;

public interface AuctionInsertRepository {
	void insertAuction(Auction auction);
}
